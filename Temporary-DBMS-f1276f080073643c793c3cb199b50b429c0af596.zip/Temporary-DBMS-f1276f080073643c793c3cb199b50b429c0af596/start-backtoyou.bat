@echo off
setlocal EnableExtensions

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"
set "BACKEND_DIR=%ROOT_DIR%\backend"
set "FRONTEND_DIR=%ROOT_DIR%\frontend"

title BackToYou - Launcher
echo ============================================================
echo   BackToYou - Public Transport Lost Item Tracker Launcher
echo ============================================================
echo.

:: 1. Verify Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js was not found in PATH. Please install Node.js v18+ first.
    pause
    exit /b 1
)

:: 2. Start / Verify Database (MongoDB on port 27017)
echo [1/3] Checking MongoDB database...
netstat -ano | findstr /C:":27017 " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo       MongoDB is already running on port 27017.
) else (
    echo       Starting MongoDB Windows service...
    net start MongoDB >nul 2>&1
    if errorlevel 1 (
        echo       Attempting elevated start for MongoDB service...
        powershell -NoProfile -Command "try { Start-Process -FilePath 'net' -ArgumentList 'start MongoDB' -Verb RunAs -Wait -WindowStyle Hidden } catch {}" >nul 2>&1
    )
    netstat -ano | findstr /C:":27017 " | findstr /C:"LISTENING" >nul 2>&1
    if not errorlevel 1 (
        echo       MongoDB started successfully on port 27017.
    ) else (
        echo       [WARN] Local MongoDB service did not start on port 27017.
        echo              Backend will fall back to embedded in-memory DB if in development mode.
    )
)
echo.

:: 3. Ensure dependencies and .env exist
if not exist "%ROOT_DIR%\node_modules" if not exist "%BACKEND_DIR%\node_modules" (
    echo [Setup] Installing dependencies...
    pushd "%ROOT_DIR%"
    call npm install
    popd
)

if not exist "%BACKEND_DIR%\.env" (
    if exist "%BACKEND_DIR%\.env.example" (
        copy /Y "%BACKEND_DIR%\.env.example" "%BACKEND_DIR%\.env" >nul
    )
)

:: 4. Start Backend API Server (Port 5000)
echo [2/3] Checking Backend API server (Port 5000)...
netstat -ano | findstr /C:":5000 " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo       Backend is already listening on port 5000.
) else (
    echo       Starting Backend server in a new window...
    start "BackToYou Backend (Port 5000)" /D "%BACKEND_DIR%" cmd /k npm start
)
echo.

:: 5. Start Frontend Static Server (Port 5500)
echo [3/3] Checking Frontend server (Port 5500)...
netstat -ano | findstr /C:":5500 " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo       Frontend is already listening on port 5500.
) else (
    python --version >nul 2>&1
    if not errorlevel 1 (
        echo       Starting Frontend server with Python on port 5500...
        start "BackToYou Frontend (Port 5500)" /D "%FRONTEND_DIR%" cmd /k python -m http.server 5500
    ) else (
        echo       Starting Frontend server with npx serve on port 5500...
        start "BackToYou Frontend (Port 5500)" /D "%FRONTEND_DIR%" cmd /k npx --yes serve -l 5500 .
    )
)
echo.

:: 6. Wait briefly and open browser
echo Waiting for services to initialize...
ping -n 4 127.0.0.1 >nul
start "" "http://localhost:5500/"

echo ============================================================
echo   All services launched!
echo   - Frontend : http://localhost:5500
echo   - Backend  : http://localhost:5000/api/health
echo   - Database : mongodb://127.0.0.1:27017/backtoyou
echo ============================================================
echo.
echo Close the Backend / Frontend terminal windows when you want to stop them.
pause