const mongoose = require('mongoose');
const crypto = require('crypto');

const auditLogSchema = new mongoose.Schema(
  {
    auditId: {
      type: String,
      unique: true,
      index: true,
      default: function () {
        return `AUD-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
      },
    },
    actor: {
      type: String,
      required: true,
      default: 'System',
    },
    email: {
      type: String,
      default: '',
    },
    role: {
      type: String,
      default: 'System',
    },
    category: {
      type: String,
      required: true,
    },
    action: {
      type: String,
      required: true,
    },
    target: {
      type: String,
      default: '',
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('AuditLog', auditLogSchema);
