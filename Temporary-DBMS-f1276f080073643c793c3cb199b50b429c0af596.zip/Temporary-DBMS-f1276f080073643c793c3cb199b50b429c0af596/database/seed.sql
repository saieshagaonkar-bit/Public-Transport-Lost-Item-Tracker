-- =====================================================================
-- BackToYou — Demo Seed Data (SQL Equivalent of database/seedData.js)
-- =====================================================================

USE backtoyou;

-- 1. Users (Demo password for all seeded accounts: TransitPass2026!)
INSERT INTO users (id, name, email, password_hash, phone, role, station, status) VALUES
(1, 'Sarah Jenkins', 'sarah.jenkins@metrotransit.org', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 234-8921', 'Passenger', 'Grand Central Terminal', 'Active'),
(2, 'Marcus Vance', 'm.vance@transitdev.io', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 890-1122', 'Passenger', 'Civic Center Station', 'Active'),
(3, 'David Sterling', 'd.sterling@metrotransit.org', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 345-6789', 'Passenger', 'South Terminal Station', 'Active'),
(4, 'Officer Miller', 'custody.civic@metrotransit.org', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 456-7890', 'Staff', 'Civic Center Station', 'Active'),
(5, 'Officer Patel', 'spatel@southtransit.gov', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 567-8901', 'Staff', 'South Terminal Station', 'Active'),
(6, 'Depot Clerk J. Adams', 'jadams@transitdept.org', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 678-9012', 'Staff', 'Express Route Depot', 'Suspended'),
(7, 'Director Vance', 'admin.director@transit.gov', '$2a$10$demoPlaceholderHashForTransitPass2026', '+1 (555) 999-0000', 'Admin', 'Central Operations', 'Active');

-- 2. Items
INSERT INTO items (id, custom_id, title, type, category, color, brand, description, transit_type, route, location, incident_date, time_approx, custody_location, status, image, reported_by, reporter_name, reporter_email, reporter_role, claimed) VALUES
(1, 'TRX-782194', 'Grey Laptop', 'Lost', 'Electronics', 'Grey with charcoal sleeve', 'Apple', 'Grey laptop left near seats on Blue Line. Has a charcoal felt sleeve and small stickers.', 'Metro', 'Blue Line 2 (Carriage #304)', 'Boarded Central Hub towards Civic Center', '2026-10-09', '08:35 AM Morning Peak', 'Reported missing by passenger', 'Possible Match', NULL, 2, 'Marcus V.', 'm.vance@transitdev.io', 'Passenger', FALSE),
(2, 'TRX-491028', 'Grey Laptop with Case', 'Found', 'Electronics', 'Dark Grey with charcoal sleeve', 'Apple', 'Laptop found in protective felt sleeve on train seats after terminating run.', 'Metro', 'Blue Line 2 (Platform 3)', 'Civic Center Station Terminal Concourse', '2026-10-09', '09:10 AM Custody Handover', 'Civic Center Station Custody Desk Vault #B2', 'Possible Match', 'found_laptop.jpg', 4, 'Station Staff', 'custody.civic@metrotransit.org', 'Station Staff', TRUE),
(3, 'TRX-310892', 'Brown Leather Bag', 'Lost', 'Bags & Wallets', 'Brown with brass buckles', 'Leather Bag', 'Brown leather shoulder bag. Contains sketchbooks and drawing pencil pouch.', 'Train', 'Northern Regional Link (Express #14)', 'Grand Central Terminal departure track 7', '2026-10-08', '17:45 PM Evening Commute', 'Reported missing by passenger', 'Open', NULL, 1, 'Sarah Jenkins', 'sarah.jenkins@metrotransit.org', 'Passenger', FALSE),
(4, 'TRX-824190', 'Brown Sunglasses', 'Found', 'Accessories', 'Brown with gold accents', 'Ray-Ban', 'Brown sunglasses in black protective clamshell case found on bus seats.', 'Bus', 'Metro City Bus Route 42', 'Cross-town bus stop at Lexington Ave', '2026-10-09', '14:15 PM Midday Service', 'Main Bus Depot Holding Locker 12', 'Open', 'found_sunglasses.jpg', 4, 'Bus Driver', 'depot42@metrobus.gov', 'Driver', FALSE),
(5, 'TRX-905142', 'Silver Headphones', 'Found', 'Electronics', 'Silver Grey', 'Sony', 'Silver wireless over-ear headphones enclosed in zippered light grey travel case.', 'Station', 'Grand Central Hub Waiting Lounge', 'Bench beside Gate 14 East concourse', '2026-10-10', '11:20 AM Morning', 'Grand Central Lost Property Office Desk #1', 'Claim Pending', 'found_headphones.jpg', 4, 'Station Staff', 'grandcentral.security@metro.org', 'Station Staff', TRUE),
(6, 'TRX-639108', 'Brown Leather Wallet', 'Lost', 'Bags & Wallets', 'Caramel Brown leather', 'Leather Wallet', 'Brown leather bifold wallet with transport pass and identity cards inside.', 'Metro', 'Red Subway Line 1', 'Transfer connection at Metro South Hub', '2026-10-07', '19:10 PM', 'Reported missing by passenger', 'Open', NULL, 3, 'David Sterling', 'd.sterling@metrotransit.org', 'Passenger', FALSE),
(7, 'TRX-119284', 'Yellow Winter Scarf', 'Found', 'Clothing', 'Mustard Yellow knit', 'Wool Scarf', 'Warm knitted yellow winter scarf found on the rear seats of bus 101.', 'Bus', 'Express Route 101', 'Rear passenger seats', '2026-10-08', '21:00 PM Night Run', 'Depot Customer Service Lost Bin', 'Open', 'found_scarf.jpg', 4, 'Bus Driver', 'jadams@transitdept.org', 'Driver', FALSE),
(8, 'TRX-553198', 'Keys with Keychain', 'Found', 'Keys', 'Brass & silver keys with brown tag', 'Door keys', 'Set of standard house door keys on a round metal ring with a brown leather tag.', 'Station', 'South Terminal Station', 'Ticket Vending Kiosk #4', '2026-10-06', '13:40 PM', 'South Terminal Security Office', 'Recovered', 'normal_keys.jpg', 5, 'Station Security', 'spatel@southtransit.gov', 'Station Staff', TRUE);

-- 3. Claims
INSERT INTO claims (id, claim_id, item_ref_id, item_custom_id, item_title, claimant_id, claimant_name, claimant_phone, secret_details, pickup_station, status, reviewed_by, reviewer_name, review_notes) VALUES
(1, 'CLM-9031', 5, 'TRX-905142', 'Silver Headphones', 1, 'Sarah Jenkins', '+1 (555) 234-8921', 'Device name in Bluetooth is ''Sarah XM5''. The inside headband has a tiny gray sticker from my workplace audio lab. Carrying case has a blue USB-C charging cable inside the mesh compartment.', 'Grand Central Terminal Lost & Found Office', 'Pending Review', NULL, NULL, NULL),
(2, 'CLM-4812', 2, 'TRX-491028', 'Grey Laptop with Case', 2, 'Marcus Vance', '+1 (555) 890-1122', 'MacBook Pro 14-inch, Serial number ending in -H92. Lock screen avatar is an orange transit schematic map. Developer stickers include Rust and Docker logos on top lid.', 'Civic Center Station Custody Desk Vault #B2', 'Pending Review', NULL, NULL, NULL),
(3, 'CLM-8120', 8, 'TRX-553198', 'Keys with Keychain', 3, 'David Sterling', '+1 (555) 345-6789', 'Apartment #302 stamped on the small brass key. Leather tag engraved with initial "D".', 'South Terminal Station Security Office', 'Approved', 5, 'Officer Patel', 'Keys matched apartment number and owner ID.');

-- 4. Notifications
INSERT INTO notifications (user_id, title, body, type, related_item_id, related_item_custom_id, is_read) VALUES
(2, 'High-Confidence Match Detected!', 'Your lost report ''Grey Laptop'' matches found item ''Grey Laptop with Case'' at Civic Center (94% Match).', 'match', 2, 'TRX-491028', FALSE),
(1, 'Claim Submitted for Review', 'Claim #CLM-9031 for Silver Headphones is queued for transit verification.', 'claim_submitted', 5, 'TRX-905142', FALSE),
(3, 'Item Safely Handed Over', 'Keys with Keychain (TRX-553198) was successfully handed over to verified owner at South Terminal.', 'item_recovered', 8, 'TRX-553198', TRUE);

-- 5. Feedback
INSERT INTO feedbacks (feedback_id, user_id, name, email, rating, category, message) VALUES
('FDB-1004', 2, 'Marcus Vance', 'm.vance@transitdev.io', 5, 'Claim process', 'Claiming my laptop was quick and clear. I got a handover voucher the same afternoon.'),
('FDB-1003', 3, 'David Sterling', 'd.sterling@metrotransit.org', 3, 'Search & matching', 'Search works well, but I would like to filter by the exact station where I lost my item.'),
('FDB-1002', 1, 'Sarah Jenkins', 'sarah.jenkins@metrotransit.org', 4, 'Reporting an item', 'The report form is easy to follow. A photo upload for lost items would help too.'),
('FDB-1001', 2, 'Marcus Vance', 'm.vance@transitdev.io', 2, 'Bug / problem', 'I did not get a notification when a possible match was found for my scarf.');

-- 6. Audit Logs
INSERT INTO audit_logs (audit_id, actor, email, role, category, action, target) VALUES
('AUD-0005', 'Officer Miller', 'custody.civic@metrotransit.org', 'Staff', 'Access', 'Signed in to Staff Portal', 'custody.civic@metrotransit.org'),
('AUD-0004', 'Officer Patel', 'spatel@southtransit.gov', 'Staff', 'Claims', 'Approved claim & issued handover voucher', 'CLM-8120 - Keys with Keychain'),
('AUD-0003', 'Director Vance', 'admin.director@transit.gov', 'Admin', 'Users', 'Suspended account', 'Depot Clerk J. Adams (USR-2003)'),
('AUD-0002', 'Director Vance', 'admin.director@transit.gov', 'Admin', 'Disposal', 'Approved disposal (donation)', 'DSP-7003 - Umbrella (Black)'),
('AUD-0001', 'System', '', 'System', 'Access', 'Automatic nightly custody integrity check passed', 'All station vaults');

-- 7. Disposals
INSERT INTO disposals (disposal_id, item_title, category, station, days_held, method, status) VALUES
('DSP-7001', 'Navy Umbrella', 'Accessories', 'Civic Center Custody Desk', 112, 'Donate to charity', 'Due for Disposal'),
('DSP-7002', 'Child''s Backpack', 'Bags & Wallets', 'South Terminal Security Office', 98, 'Donate to charity', 'Due for Disposal'),
('DSP-7004', 'Wired Earphones', 'Electronics', 'Grand Central Lost & Found', 94, 'E-waste recycling', 'Due for Disposal'),
('DSP-7005', 'Gym Water Bottle', 'Other', 'Express Route Depot Lost Bin', 91, 'Recycle', 'Due for Disposal'),
('DSP-7003', 'Black Umbrella', 'Accessories', 'Grand Central Lost & Found', 120, 'Donate to charity', 'Disposed');

