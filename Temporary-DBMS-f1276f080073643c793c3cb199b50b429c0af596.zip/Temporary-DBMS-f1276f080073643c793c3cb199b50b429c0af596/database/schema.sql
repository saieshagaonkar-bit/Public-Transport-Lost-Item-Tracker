-- =====================================================================
-- BackToYou — Public Transport Lost Item Tracker
-- Relational SQL Schema (Equivalent to the 7 MongoDB Collections)
-- Note: The live Node.js backend uses MongoDB + Mongoose (see database/models/).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS backtoyou;
USE backtoyou;

-- 1. Users (Passengers, Staff, Admins)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(30) DEFAULT '',
    address VARCHAR(255) DEFAULT '',
    role ENUM('Passenger', 'Staff', 'Admin') NOT NULL DEFAULT 'Passenger',
    station VARCHAR(150) DEFAULT 'Central Operations',
    status ENUM('Active', 'Suspended') NOT NULL DEFAULT 'Active',
    last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role_status (role, status)
);

-- 2. Items (Lost & Found Reports)
CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    custom_id VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(100) NOT NULL,
    type ENUM('Lost', 'Found') NOT NULL,
    category ENUM('Electronics', 'Bags & Wallets', 'Documents', 'Accessories', 'Clothing', 'Keys', 'Other') NOT NULL,
    color VARCHAR(100) NOT NULL,
    brand VARCHAR(100) DEFAULT 'Unspecified',
    description TEXT NOT NULL,
    transit_type ENUM('Metro', 'Bus', 'Train', 'Station') NOT NULL,
    route VARCHAR(150) NOT NULL,
    location VARCHAR(255) NOT NULL,
    incident_date DATE NOT NULL,
    time_approx VARCHAR(80) DEFAULT 'Not specified',
    custody_location VARCHAR(255) DEFAULT 'Pending Custodial Match',
    status ENUM('Open', 'Possible Match', 'Claim Pending', 'Recovered', 'Archived') NOT NULL DEFAULT 'Open',
    image TEXT NULL,
    reported_by INT NOT NULL,
    reporter_name VARCHAR(100) NOT NULL,
    reporter_email VARCHAR(255) NOT NULL,
    reporter_role ENUM('Passenger', 'Conductor', 'Driver', 'Station Staff') NOT NULL DEFAULT 'Passenger',
    claimed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (reported_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_items_filters (type, category, transit_type, status)
);

-- 3. Claims (Ownership Verification Claims)
CREATE TABLE IF NOT EXISTS claims (
    id INT AUTO_INCREMENT PRIMARY KEY,
    claim_id VARCHAR(20) NOT NULL UNIQUE,
    item_ref_id INT NOT NULL,
    item_custom_id VARCHAR(20) NOT NULL,
    item_title VARCHAR(100) NOT NULL,
    claimant_id INT NOT NULL,
    claimant_name VARCHAR(100) NOT NULL,
    claimant_phone VARCHAR(30) NOT NULL,
    secret_details TEXT NOT NULL,
    pickup_station VARCHAR(255) NOT NULL,
    status ENUM('Submitted', 'Pending Review', 'Under Review', 'Approved', 'Rejected', 'Completed') NOT NULL DEFAULT 'Pending Review',
    reviewed_by INT NULL,
    reviewer_name VARCHAR(100) NULL,
    review_notes TEXT NULL,
    reviewed_at DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (item_ref_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY (claimant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_claims_status (status)
);

-- 4. Notifications (In-App Alerts)
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    type ENUM('match', 'claim_submitted', 'claim_approved', 'claim_rejected', 'item_recovered', 'system') NOT NULL DEFAULT 'system',
    related_item_id INT NULL,
    related_item_custom_id VARCHAR(20) NULL,
    related_claim_id INT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (related_item_id) REFERENCES items(id) ON DELETE SET NULL,
    FOREIGN KEY (related_claim_id) REFERENCES claims(id) ON DELETE SET NULL,
    INDEX idx_notifications_user_read (user_id, is_read)
);

-- 5. Feedback (Passenger Ratings & Comments)
CREATE TABLE IF NOT EXISTS feedbacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    feedback_id VARCHAR(40) NOT NULL UNIQUE,
    user_id INT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) DEFAULT '',
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    category ENUM('Ease of use', 'Reporting an item', 'Search & matching', 'Claim process', 'Bug / problem', 'Suggestion', 'Other') NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- 6. Audit Logs (Chain-of-Custody & Access Events)
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    audit_id VARCHAR(50) NOT NULL UNIQUE,
    actor VARCHAR(100) NOT NULL DEFAULT 'System',
    email VARCHAR(255) DEFAULT '',
    role ENUM('Passenger', 'Staff', 'Admin', 'System') NOT NULL DEFAULT 'System',
    category VARCHAR(60) NOT NULL,
    action VARCHAR(255) NOT NULL,
    target VARCHAR(255) DEFAULT '',
    timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_timestamp (timestamp DESC)
);

-- 7. Disposals (Unclaimed Property Past 90-Day Retention)
CREATE TABLE IF NOT EXISTS disposals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    disposal_id VARCHAR(20) NOT NULL UNIQUE,
    item_ref_id INT NULL,
    item_title VARCHAR(100) NOT NULL,
    category VARCHAR(60) NOT NULL,
    station VARCHAR(255) NOT NULL,
    days_held INT NOT NULL DEFAULT 90,
    method VARCHAR(100) NOT NULL DEFAULT 'Donate to charity',
    status ENUM('Due for Disposal', 'Hold Extended', 'Disposed') NOT NULL DEFAULT 'Due for Disposal',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (item_ref_id) REFERENCES items(id) ON DELETE SET NULL
);

